public class Game {
    private Board gameBoard;

    private String currentPlayer;

    private String player1;

    private String player2;

    /**
     * the game constructor
     */
    public Game() {

    }

    /**
     * runs a game of Stratego
     */
    public void gameLoop() {

    }

    /**
     * switch the current player
     */
    private void switchPlayer() {

    }
}
