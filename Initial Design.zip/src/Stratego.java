public class Stratego {
    public static void main(String[] args) {

    }
}
